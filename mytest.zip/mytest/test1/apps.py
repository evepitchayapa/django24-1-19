from django.apps import AppConfig


class Test1Config(AppConfig):
    name = 'test1'
